﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CupcakeYPasteles.Models
{
    public class VentasMes
    {

        public int ano { get; set; }
        public int mes { get; set; }
        public double valor { get; set; }
    }
}